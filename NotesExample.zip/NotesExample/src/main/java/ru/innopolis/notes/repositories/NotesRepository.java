package ru.innopolis.notes.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.innopolis.notes.models.Note;

public interface NotesRepository extends JpaRepository<Note, Long>
{
    //note
}
