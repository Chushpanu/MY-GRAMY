package ru.innopolis.notes.models;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.time.LocalDate;

@Data                        // аннотация, чтоб обеспечить доступ к объектам
@Entity                      // аннотация, что объекты надо хранить в БД

public class Note
{
    private long id;         // номер заметки
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //автоматическая генерация новых индитификатор

    private String title;    // название заметки
    private LocalDate date;  // дата создания
    private String text;     // текст заметки
}
