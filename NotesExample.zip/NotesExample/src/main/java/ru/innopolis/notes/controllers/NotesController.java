package ru.innopolis.notes.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import ru.innopolis.notes.models.Note;
import ru.innopolis.notes.repositories.NotesRepository;

import java.time.LocalDate;

@Controller
public class NotesController
{
    @Autowired
    private NotesRepository notesRepository;

    @GetMapping("/notes")
    public String getNotesPage()
    {
        return "notes";
    }

    @GetMapping("/notes/add")
    public String getAddNotesPage(Note note)
    {
        return "add_note";
    }

    @PostMapping("/notes")
    public String addNote(Note note)
    {
        note.setDate(LocalDate.now());
        notesRepository.save(note);

        return "redirect:/notes";
    }

}
